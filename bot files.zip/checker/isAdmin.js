module.exports = (member) =>{
  return member.hasPermission("ADMINISTRATOR");
}